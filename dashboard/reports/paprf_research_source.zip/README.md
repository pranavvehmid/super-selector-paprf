# PAPRF native LaTeX report

The source archive contains the main document, generated evidence appendices, 12 figures, and 18 Markdown research chapters. Extract it and run tectonic paprf_research.tex from the extracted directory. A full TeX installation can instead run latexmk -pdf paprf_research.tex. The font pairing uses the Times-compatible mathptmx package.

In this repository run python scripts/verify_paprf_rebuild.py against the original six CSV files, then run python scripts/build_paprf_latex.py --engine followed by the full path to Tectonic. The generator derives the report tables from the same evidence loader as the dashboard, checks the contextual CSV list order and scores, recomputes all 20 contextual indices, and writes the evidence run ID. Run it without the engine option to generate sources only. Refresh the dashboard with python scripts/build_dashboard_data.py after building the report.
